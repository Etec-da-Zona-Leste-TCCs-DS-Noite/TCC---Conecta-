package br.edu.EtecZonaLeste.Conecta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConectaApplicationTests {

	@Test
	void contextLoads() {
	}

}
